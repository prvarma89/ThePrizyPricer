package bean;

public class ProductLoader {
	private String store;
	private String productId;
	private Double price;
	private String notes;
	private String entryDate;
	
	
		
	public ProductLoader() {
		
	}
	
	public ProductLoader(String store, String productId, Double price,
			String notes, String entryDate, String location) {
		this.store = store;
		this.productId = productId;
		this.price = price;
		this.notes = notes;
		this.entryDate = entryDate;
		
	}
	public String getStore() {
		return store;
	}
	public void setStore(String store) {
		this.store = store;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	
	

	
}
