package bean;

public class ProductViewer {
	private String barCode;
	private String productName;
	private String productDesc;
	private String averagePrice;
	private String lowestPrice;
	private String highestPrice;
	private String idealPrice;
	private String numberPricesCol;

	
	
	public ProductViewer() {
		
	}
	public ProductViewer(String barCode, String productName,
			String productDesc, String averagePrice, String lowestPrice,
			String highestPrice, String idealPrice, String numberPricesCol,
			String location) {
		super();
		this.barCode = barCode;
		this.productName = productName;
		this.productDesc = productDesc;
		this.averagePrice = averagePrice;
		this.lowestPrice = lowestPrice;
		this.highestPrice = highestPrice;
		this.idealPrice = idealPrice;
		this.numberPricesCol = numberPricesCol;
		
	}
	public String getBarCode() {
		return barCode;
	}
	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public String getAveragePrice() {
		return averagePrice;
	}
	public void setAveragePrice(String averagePrice) {
		this.averagePrice = averagePrice;
	}
	public String getLowestPrice() {
		return lowestPrice;
	}
	public void setLowestPrice(String lowestPrice) {
		this.lowestPrice = lowestPrice;
	}
	public String getHighestPrice() {
		return highestPrice;
	}
	public void setHighestPrice(String highestPrice) {
		this.highestPrice = highestPrice;
	}
	public String getIdealPrice() {
		return idealPrice;
	}
	public void setIdealPrice(String idealPrice) {
		this.idealPrice = idealPrice;
	}
	public String getNumberPricesCol() {
		return numberPricesCol;
	}
	public void setNumberPricesCol(String numberPricesCol) {
		this.numberPricesCol = numberPricesCol;
	}
	
	


}
