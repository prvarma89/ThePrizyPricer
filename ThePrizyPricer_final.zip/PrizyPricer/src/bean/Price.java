package bean;

public class Price {
	private double sum;
	private double average;
	private double highest;
	private double lowest;
	private double ideal;
	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	public double getAverage() {
		return average;
	}
	public void setAverage(double average) {
		this.average = average;
	}
	public double getHighest() {
		return highest;
	}
	public void setHighest(double highest) {
		this.highest = highest;
	}
	public double getLowest() {
		return lowest;
	}
	public void setLowest(double lowest) {
		this.lowest = lowest;
	}
	public double getIdeal() {
		return ideal;
	}
	public void setIdeal(double ideal) {
		this.ideal = ideal;
	}


}
