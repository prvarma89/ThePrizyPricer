/*
 @Author Pramodkumar Varma (pramodvarma89@gmail.com)
 * 
 * */

package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.handler.MessageContext;

import exception.ClientServerException;

import Util.MessageConstants;
import bean.ProductCombinedDetails;
import bean.ProductDetails;
import bean.ProductLoader;
import bean.ProductViewer;


public class ProductLaoderDaoImp implements IProductLoaderDao {
	
	DBConnection database =null;
	Connection connection =null;
	ResultSet resultSet=null;
	
	public  ProductLaoderDaoImp(DBConnection database){
		
		this.database=database;
	}
	
	
	@Override
	public int saveProductPriceDao(ProductLoader product) throws ClientServerException {
		
	String query =	"insert into price_loader(store,pid,price,notes,entrydate) values(?,?,?,?,?)";
	int flag =0;
	 connection =  database.getConnection();		
     try {
		
    	 PreparedStatement ps = connection.prepareStatement(query);
    	 
    	 ps.setString(1,product.getStore());
    	 ps.setString(2, product.getProductId());
    	 ps.setDouble(3,product.getPrice());
    	 ps.setString(4, product.getNotes());
          ps.setString(5, product.getEntryDate());
    	flag = ps.executeUpdate();
    	System.out.println("record updated successfully "+flag);
	
     } catch (Exception e) {
		// TODO Auto-generated catch block
    	 System.out.println(MessageConstants.ENTRY_FAILED);
    	// e.printStackTrace(); // log exception 
    	 
    	 new ClientServerException(MessageConstants.ENTRY_FAILED,MessageConstants.message.get(MessageConstants.ENTRY_FAILED));
		
	}
     return flag;
	}


	@Override
	public List<ProductDetails> getProductMasterListDao(String productName)
			throws ClientServerException {
		
		String name = productName.toUpperCase();
		String query =	"select * from product_master_list where product_name like'%"+name+"%'";
		int flag =0;
		
		List<ProductDetails> productList = new ArrayList<>();
		 connection =  database.getConnection();		
	     try {
	    	
			
	 			Statement stmt = (Statement) connection.createStatement();
	 			resultSet = stmt.executeQuery(query);
	 			
	 			while (resultSet.next()) {
	 				ProductDetails details = new ProductDetails();
					details.setProductId(resultSet.getString("pid"));
					details.setProductName(resultSet.getString("product_name"));
					details.setProductDesc(resultSet.getString("product_description"));
					productList.add(details);
					
				}
	 			
	 				connection.close();

	 			} 		
	 		 catch (Exception e) {
	    	 	 new ClientServerException(MessageConstants.DATABASE_CONNECTION_ERROR,MessageConstants.message.get(MessageConstants.DATABASE_CONNECTION_ERROR));
		      }	
	
	     return productList;     
	}


	@Override
	public List<ProductCombinedDetails> getProductDetailsDao(String productCode)
			throws ClientServerException {
		String name = productCode.toUpperCase();
		String query =	"select pm.pid,pm.product_name,pm.product_description,pl.store,pl.price,pl.notes,pl.entrydate from product_master_list pm inner join price_loader pl on pm.pid=pl.pid where  pm.product_name ='"+name+"'";
		
		List<ProductCombinedDetails> productList = new ArrayList<>();
		 connection =  database.getConnection();		
	     try {
	    	
			
	 			Statement stmt = connection.createStatement();
	 			resultSet = stmt.executeQuery(query);
	 			
	 			while (resultSet.next()) {
	 				ProductCombinedDetails details = new ProductCombinedDetails();
					details.setProductId(resultSet.getString("pid"));
					details.setProductName(resultSet.getString("product_name"));
					details.setProductDesc(resultSet.getString("product_description"));
					details.setStore(resultSet.getString("store"));
					details.setPrice(resultSet.getDouble("price"));
					details.setNotes(resultSet.getString("notes"));
					details.setEntryDate(resultSet.getString("entrydate"));

					productList.add(details);
					
				}
	 			
	 				connection.close();

	 			} 		
	 		 catch (Exception e) {
	    	 	 new ClientServerException(MessageConstants.DATABASE_CONNECTION_ERROR,MessageConstants.message.get(MessageConstants.DATABASE_CONNECTION_ERROR));
		      }	
	
	     return productList;     

	}


		
	
	
	
	
	
	 public static void main(String str[])
		{
			
			DBConnection database =  new DBConnection();
			ProductLaoderDaoImp dao=new ProductLaoderDaoImp(database);
			//ProductLoader product=  new ProductLoader("RelianceMart","XXXX0008",20.50f,"Notes","20-Mar-2017","pune");
			
	           try {
				//dao.saveProductPriceDao(product);
				List<ProductDetails> list = dao.getProductMasterListDao("cas");
				for(ProductDetails pd: list){
					System.out.println(pd.getProductId());
					System.out.println(pd.getProductName());

				}
			} catch (ClientServerException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getErrorCode());
				System.out.println(e.getMessage());
				//e.printStackTrace();
			}
		}  
}  // END OF CLASS



//select * from price_loader pl , product_details pd where pl.pid=pd.pid