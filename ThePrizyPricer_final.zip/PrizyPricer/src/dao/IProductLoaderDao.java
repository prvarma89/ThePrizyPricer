package dao;

import java.util.List;

import exception.ClientServerException;
import bean.ProductCombinedDetails;
import bean.ProductDetails;
import bean.ProductLoader;
import bean.ProductViewer;

public interface IProductLoaderDao {
	
	public int saveProductPriceDao(ProductLoader productLoader) throws ClientServerException;
	
	public List<ProductDetails> getProductMasterListDao(String productName) throws ClientServerException;
	
	public List<ProductCombinedDetails> getProductDetailsDao(String productCode) throws ClientServerException;


}
