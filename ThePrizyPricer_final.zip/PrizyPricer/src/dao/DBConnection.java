/*
 * @Author Pramodkumar Varma (pramodvarma89@gmail.com)
 * 
 * */

package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	Connection con;
	String dbUrl;
	String driverClass;
	
	public DBConnection() {
		dbUrl = "jdbc:sqlite:E:\\PrizyPricer";
		driverClass = "org.sqlite.JDBC";
	}

	// =================================** BUILD CONNECTION	// **===========================//
	public Connection getConnection() {

		Connection con = null;
		try {

			Class.forName(driverClass);

			con = DriverManager.getConnection(dbUrl);

			System.out.println("successfull!!");

		} catch (ClassNotFoundException e) {
			System.out.println("Wrong Driver class!!");
			//e.printStackTrace();
		} catch (SQLException e) {

			System.out.println("could not get the connection");
			//e.printStackTrace();
		}

		return con;
	}

	// =================================** CLOSE CONNECTION	// **===========================//
	public void closeConnection() {
		try {
			if (con != null) {
				con.close();
				con = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
