package controller;

import java.util.List;

import service.PrizyPricerServiceImp;
import bean.ProductDetails;
import bean.ProductLoader;
import bean.ProductViewer;
import exception.ClientServerException;

public class PrizyPriceControllerImp implements IPrizyPriceController {
	
	private final PrizyPricerServiceImp  service ;	
   
	   public PrizyPriceControllerImp(){
		   service= new PrizyPricerServiceImp();
           }
	
	@Override
	public int addProductLoaderController(ProductLoader product) {
			  
		try {
			System.out.println("controller 1");
			return service.addProductLoaderService(product);
			

		} catch (ClientServerException e) {
			
			System.out.println(e.getErrorCode() + e.getMessage()); // log
			return 0;
		}
		
	}

	@Override
	public List<ProductDetails> getProductMasterListController(String productName) {
		try {
			System.out.println("controller 1");
			return service.getProductMasterListService(productName);
			

		} catch (ClientServerException e) {
			
			System.out.println(e.getErrorCode() + e.getMessage()); // log
			return null;
		}
	}

	@Override
	public ProductViewer getProductDetailsController(String productCode){
		
		try {
			return service.getProductDetailsService(productCode);
		} catch (ClientServerException e) {
		
						System.out.println(e.getErrorCode() + e.getMessage()); // log
						return null;
		}
	}

}
