package controller;

import java.util.List;

import bean.ProductDetails;
import bean.ProductLoader;
import bean.ProductViewer;
import exception.ClientServerException;

public interface IPrizyPriceController {
	
	public int addProductLoaderController(ProductLoader product);//// throws ClientServerException;
	
	public List<ProductDetails> getProductMasterListController(String productName);//// throws ClientServerException;

	public ProductViewer getProductDetailsController(String productCode);// throws ClientServerException;


}
