package Util;
import java.util.HashMap;
import java.util.Map;

public class MessageConstants {
public static Map<String,String> message;
	
	public static String ENTRY_FAILED="ENTRY_FAILED";
	public static String ENTRY_SAVED="ENTRY_SAVED";
	public static String DATABASE_CONNECTION_ERROR="DATABASE_CONNECTION_ERROR";
    public static String INVALID_TEXT_FORMAT="INVALID_TEXT_FORMAT";
    public static String INVALID_PRICE_FORMAT="INVALID_PRICE_FORMAT";
    public static String INVALID_INPUT="VALID_INPUT";
    public static String INVALID_STORE_NAME="INVALID_STORE_NAME";
    public static String INVALID_PID="INVALID_PID";
    public static String INVALID_PRICE="INVALID_PRICE";
    public static String INVALID_NOTES="INVALID_NOTES";
    public static String PRODUCT_NOT_FOUND="PRODUCT_NOT_FOUND";

   


	static {
		
		message=new HashMap<String,String>();
		
		message.put(ENTRY_FAILED, "Record not saved to database");
		message.put(ENTRY_SAVED, "Record saved successfully to database");
		message.put(DATABASE_CONNECTION_ERROR, "Database connection error");
		message.put(INVALID_TEXT_FORMAT, "Invalid Input formate special character not allowed");
		message.put(INVALID_PRICE_FORMAT, "Please enter valid price, Enter only numbers");
		message.put(INVALID_INPUT, "Please enter valid input");
		message.put(INVALID_STORE_NAME, "Please valid enter store name, Avoid Special charaters");
		message.put(INVALID_PID, "Please enter valid product code, Avoid Special charaters");
		message.put(INVALID_PRICE, "Please enter valid product price e.g 20.50 ");
		message.put(INVALID_NOTES, "Special charaters are not allowed e.g $,',@,; etc");
		message.put(PRODUCT_NOT_FOUND, "Product not found");
		
		
		
	}
}
