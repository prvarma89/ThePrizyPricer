package Util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import service.CalculateIdealPriceImp;
import service.ICalculateIdealPrice;

import bean.Price;
import bean.ProductCombinedDetails;

import exception.ClientServerException;

public class Utilities {

	/**
	 * To valid date input text formate. 
	 * check for special character to avoid SQL injection attack
	 * 
	 * */ 
	public static boolean validateInputPattern(String inputText) {
        boolean flag = false;
	   	if(inputText!=null){
		
	   	  Pattern pattern = Pattern.compile("[a-zA-Z0-9_()*-.+/ ]*");
	   	   Matcher matcher = pattern.matcher(inputText);
	     if (!matcher.matches()) {	
	    	 System.out.println(MessageConstants.message.get(MessageConstants.INVALID_TEXT_FORMAT)); // log error
			 flag=true;
	     }
	    		
		 } else {		
	            System.out.println(MessageConstants.message.get(MessageConstants.INVALID_INPUT));
				 flag=true;

		}	
	   	return flag;
	}

	
	/*
	   To Validate Price formate only numberic value with period allowed
	*/
	public static boolean validateInputPrice(String inputText) {
         boolean flag=false;
	   	if(inputText!=null ){
		
    	  Pattern pattern = Pattern.compile("[0-9.]*");
	   	 Matcher matcher = pattern.matcher(inputText);
	     if (!matcher.matches()) {	
	    	 System.out.println("INVALID Format   = "+ inputText);
				System.out.println(MessageConstants.message.get(MessageConstants.INVALID_PRICE_FORMAT)); // log error
				flag=true; 
	     }
	    		
		} else {		
			System.out.println(MessageConstants.message.get(MessageConstants.INVALID_INPUT)); // log error
			flag=true;
		}	
	   	
	   	return flag;
	}


 //To get current date 
public static String getDateInStringFormate()
 {
		DateFormat timeFormat = new SimpleDateFormat("dd/MM/yyyy"); 
		Date date = new Date();
        return timeFormat.format(date);
	 
 }
// This method calculate the Average , Hightest and Lowest Values from the list provide
public static Price getAverageHighesLowestPriceFromList(List<Double> combined)
{
	Price price = new Price();
	double average=0;
	double highest=0;
	double lowest=0;
	double sum=0;
	
	
	if(combined!=null)
	{
		highest=combined.get(0);
		lowest=combined.get(0);
	 for(Double p:combined){		 
	  if(!p.isNaN()) {
		 sum = sum+p.doubleValue(); // get sum of prices
		 
		 if(highest < p.doubleValue()){    // get the highest price from list
			 highest=p.doubleValue();
		 }
		 if(lowest > p.doubleValue()){    // get lowest price from list
			 lowest=p.doubleValue();
		 }
		  
	  }	 } // end for
	
	 // calculate the average 
	 if(sum>0 && combined.size()>0)
	  {
		  average = sum/combined.size(); 
	  }

	// set value to price class 
	 System.out.println("average="+average);
	 System.out.println("highest="+highest);
	 System.out.println("lowest="+lowest);
	 System.out.println("sum="+sum);
	 
	 price.setAverage(average);
	 price.setHighest(highest);
	 price.setLowest(lowest);
	 price.setIdeal(0);
	 price.setSum(sum);
	}
	
return price;
}



/**
 * Extract only  price from the Product price list
 * @param combined
 * @return
 */
public static List<Double> getPriceListFromCombinedList(List<ProductCombinedDetails> combined){
	
	List<Double> priceList = new ArrayList<>(); 

	if(combined!=null && combined.size()>0)
	{
	
	for(ProductCombinedDetails pd:combined){
		priceList.add(pd.getPrice());
	}}
	
	return priceList;
}




// Calculate Ideal Price for product.
public static String getIdealPriceForProduct(List<Double> priceList) throws ClientServerException {
	ICalculateIdealPrice calculateIdealPrice=new CalculateIdealPriceImp();
  
	double ideal = calculateIdealPrice.getIdealPriceForProduct(priceList);
	
	return String.valueOf(ideal);
}

// Calculate average from given price list
public static double calculateAverage(List<Double> price)
{
	double average=0;
	double sum=0;
	
	if(price!=null){
	for(Double d:price){		
		sum=sum + d;
	  }
	
	 if(sum>0 && price.size()>0)
	  {
		  average = sum/price.size(); 
	  }
	}
	
return average;

}



// calculate ideal price by adding profit to it
public static double getIdealPrice(double average, double percentage) {
	double ideal=0;
			if(average>0)
				{
					
				double profit = ((average/100)*percentage);
				ideal=average+profit;
				
				}
	return ideal;
}

}
