package Util;

import java.util.ArrayList;
import java.util.List;

import exception.ClientServerException;

import bean.Price;
import bean.ProductCombinedDetails;
import bean.ProductViewer;

public class ProductViewerHelper {
	
	
 public ProductViewer getFinalResultForProductViewer(List <ProductCombinedDetails> combined)throws ClientServerException{
	 
	 ProductViewer output = new ProductViewer();
	 
	 output.setBarCode(combined.get(0).getProductId());
	 output.setProductName(combined.get(0).getProductName());
	 output.setProductDesc(combined.get(0).getProductDesc());
	 output.setNumberPricesCol(String.valueOf(combined.size()));
	 
	 // get separate price list 
     List<Double> priceList = Utilities.getPriceListFromCombinedList(combined);
     
     // get highest lowest and average from price list in single iteration
     Price price = Utilities.getAverageHighesLowestPriceFromList(priceList);
     output.setHighestPrice(String.valueOf(price.getHighest()));
	 output.setLowestPrice(String.valueOf(price.getLowest()));
	 output.setAveragePrice(String.valueOf(price.getAverage()));
	 // Calculate Ideal Price for selected product 
	 output.setIdealPrice(Utilities.getIdealPriceForProduct(priceList));
	 
	 return output;
 }
	

}
