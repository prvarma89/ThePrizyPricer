package service;

import java.util.List;

import bean.ProductDetails;
import bean.ProductLoader;
import bean.ProductViewer;
import exception.ClientServerException;

public interface IPrizyPriceService {
	
	public int addProductLoaderService(ProductLoader product) throws ClientServerException;

	public List<ProductDetails> getProductMasterListService(String productName) throws ClientServerException;

	public ProductViewer getProductDetailsService(String productCode) throws ClientServerException;
}
