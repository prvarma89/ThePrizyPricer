package service;

import java.util.List;

import dao.DBConnection;
import dao.ProductLaoderDaoImp;
import Util.MessageConstants;
import Util.ProductViewerHelper;
import bean.ProductCombinedDetails;
import bean.ProductDetails;
import bean.ProductLoader;
import bean.ProductViewer;
import exception.ClientServerException;

public class PrizyPricerServiceImp implements IPrizyPriceService{

	DBConnection dbManager=null ;
	ProductLaoderDaoImp dao = null;
	
	
	public PrizyPricerServiceImp(){
		 dbManager = new DBConnection();
		 dao=new ProductLaoderDaoImp(dbManager);
	}
	
	@Override
	public int addProductLoaderService(ProductLoader product)
			throws ClientServerException {
		
	    if(dbManager !=null && product!=null)
	    {
	    System.out.println("service 1");
	    return dao.saveProductPriceDao(product);
	    }
	    else {
	    	
	    	throw new ClientServerException(MessageConstants.DATABASE_CONNECTION_ERROR,MessageConstants.message.get(MessageConstants.DATABASE_CONNECTION_ERROR));
	    }
	  }

	// get product list from master list
	@Override
	public List<ProductDetails> getProductMasterListService(String productName)
			throws ClientServerException {
		if(dbManager !=null && productName!=null)
	    {
	    	System.out.println("service 1");
	        return dao.getProductMasterListDao(productName);
	    }
	    else {
	    	
	    	throw new ClientServerException(MessageConstants.DATABASE_CONNECTION_ERROR,MessageConstants.message.get(MessageConstants.DATABASE_CONNECTION_ERROR));
	    }

	}

	// get prodcut details 
	@Override
	public ProductViewer getProductDetailsService(String productName)
			throws ClientServerException {
		 ProductViewer productView;
		if(dbManager !=null && productName!=null)
	    {
		  
	    	System.out.println("service 1");
           List<ProductCombinedDetails> combined= dao.getProductDetailsDao((productName));
	      
           System.out.println("Combined dao"+combined.size());
           if(combined.size()>0)
           {
        	   
        	   productView= new ProductViewerHelper().getFinalResultForProductViewer(combined);
        	   
        	   
        	   
           } else {
        	   
   	    	throw new ClientServerException(MessageConstants.PRODUCT_NOT_FOUND,MessageConstants.message.get(MessageConstants.PRODUCT_NOT_FOUND));

           }
	     }
	    else {
	    	
	    	throw new ClientServerException(MessageConstants.DATABASE_CONNECTION_ERROR,MessageConstants.message.get(MessageConstants.DATABASE_CONNECTION_ERROR));
	    }
		
		return productView;
	}
}
