package service;

import java.util.List;

import exception.ClientServerException;

public interface ICalculateIdealPrice {
	
	public double getIdealPriceForProduct(List<Double> price) throws ClientServerException;

}
