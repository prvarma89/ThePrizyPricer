package service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import Util.Utilities;

import exception.ClientServerException;

public class CalculateIdealPriceImp implements ICalculateIdealPrice {

	double average=0;
	double idealPrice=0;
	double percentage=20;  // change percentage in case 
	
	
	@Override
	public double getIdealPriceForProduct(List<Double> price)
			throws ClientServerException {
		 List<Double> uniquePriceList = new ArrayList<>();
		 int arraySize=0;
		 int arraySortedSize=0;

	 if(price!=null && price.size()>0)
	 {
		 arraySize = price.size();  //  size of list 
		 
		 
		 if(arraySize>4)
		 {			
			Set<Double> hs = new HashSet<>(price); // remove duplicates
			uniquePriceList.addAll(hs);
			arraySortedSize=uniquePriceList.size();
		    Collections.sort(uniquePriceList);
		    
		    if(arraySortedSize>4){
		    	
		    	uniquePriceList.remove(0);
		    	uniquePriceList.remove(0);
		    	uniquePriceList.remove(uniquePriceList.size()-1);
		    	uniquePriceList.remove(uniquePriceList.size()-1);
		    	
		    	average = Utilities.calculateAverage(uniquePriceList);
		    	idealPrice=Utilities.getIdealPrice(average,percentage);
		    	
		    }
		    else {
		    	  // calculated average + 20%
		    	average = Utilities.calculateAverage(uniquePriceList);
		    	idealPrice=Utilities.getIdealPrice(average,percentage);
		    	
		        } 
	 
		 
		 }else{ 
			    average = Utilities.calculateAverage(price);
		    	idealPrice=Utilities.getIdealPrice(average,percentage);
			 // calculate average + 20%
		 }
		 
		 
		 
		 
		 
	 }else{}

  
		
		
		
		return idealPrice;
	}

}
