/*
 * @Author Pramodkumar Varma (41443)
 * @Email :Pramodkumar.varma@zensar.in 
 * 
 * */


package forms;

	import java.sql.ResultSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JScrollPane;

import Util.MessageConstants;
import Util.Utilities;
import bean.ProductDetails;
import bean.ProductLoader;
import bean.ProductViewer;
import controller.PrizyPriceControllerImp;

import dao.ProductLaoderDaoImp;


public class ProductViewerPanel extends JFrame{

	private JPanel addPanel;
   	private JTextField searchProductTxt;
    private JTextArea addTextArea ;  
   	private JScrollPane scrollPane,descscrollPane;
    private JList productList ;   
    DefaultListModel<String> model;
    private JButton addBtnOk;	 
    private JButton cancelBtnOk;
    private JLabel barCodelbl,productDesclbl,averagePricelbl,lowestPricelbl,highestPricelbl,idealPricelbl,countPricelbl;
    private JLabel barCodelblO,productDesclblO,averagePricelblO,lowestPricelblO,highestPricelblO,idealPricelblO,countPricelblO ;
    List<ProductDetails> prodList;
    private PrizyPriceControllerImp controller;
    	    
 	    	     
    ProductLoaderPanel frame1;
    String viewMember=null;
	
     		 
	public ProductViewerPanel() 
	{
		controller = new PrizyPriceControllerImp();
		addPanel = new JPanel();
	    scrollPane = new JScrollPane();
	    model = new DefaultListModel<>();
	   

		scrollPane.setBounds(10,60, 120, 240);
		
		//================================ COMPONENT =======================//				
		    productList = new JList(model);
		    scrollPane.setViewportView(productList);
		    productList.setBackground(new Color(255,251,174));
		    productList.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		    productList.setFont(new Font("Dialog", Font.PLAIN, 12));
		    productList.setToolTipText("Additional notes regarding product price");
		    productList.setEnabled(true);
		    
		    descscrollPane = new JScrollPane();
			descscrollPane.setBounds(130,105,160,90);
		    addTextArea = new JTextArea();
		    descscrollPane.setViewportView(addTextArea);
		    addTextArea.setWrapStyleWord(true);
		    addTextArea.setLineWrap(true);
		    addTextArea.setBackground(new Color(255,251,174));
		    addTextArea.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		    addTextArea.setFont(new Font("Dialog", Font.PLAIN, 12));
		    addTextArea.setToolTipText("Product Description");
		    addTextArea.setText("hello");
		    addTextArea.setEnabled(false);
	    
		searchProductTxt = new JTextField();
		searchProductTxt.setEditable(true);
		searchProductTxt.setBounds(10,20, 160, 20);
		searchProductTxt.setBackground(new Color(255,251,174));
		searchProductTxt.setToolTipText("Search by product name");
		
		  					    
//=====================  OK BUTTON SAVE RECORD TO DATA BASE=============================//
		    
		addBtnOk = new JButton("SEARCH");
		addBtnOk.setBounds(180, 20, 100, 20);
		addBtnOk.setToolTipText("Search");
		addBtnOk.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {

			model.clear();
			prodList=null;
			String productName = searchProductTxt.getText().trim();
			if (productName.length() < 1 || Utilities.validateInputPattern(productName)) {
				JOptionPane.showMessageDialog(frame1,
						MessageConstants.message.get(MessageConstants.INVALID_STORE_NAME));
				
			}
			else {
             
								
				prodList = controller.getProductMasterListController(productName); // 
				ProductLoaderPanel frame1 = null;
				if (prodList.isEmpty()) {

					JOptionPane.showMessageDialog(frame1,
							MessageConstants.message.get(MessageConstants.PRODUCT_NOT_FOUND));
					searchProductTxt.setText("");
					
					//addTextArea.setText("");
				} else {
					for(ProductDetails pd:prodList)
					{
					model.addElement(pd.getProductName());
					}
				}
			} // else end
			barCodelblO.setText("");
			averagePricelblO.setText("");
			lowestPricelblO.setText("");
			highestPricelblO.setText("");
			idealPricelblO.setText("");
			countPricelblO.setText("");
			addTextArea.setText("");
		}

	}); // end of ActionListener
		
// =============== RESET BUTTON ================================//
		cancelBtnOk = new JButton("RESET");
		cancelBtnOk.setBounds(160, 280, 100, 25);
		cancelBtnOk.setToolTipText("Reset fields");
		cancelBtnOk.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			
			searchProductTxt.setText("");
		
						}

	}); // end of ActionListener

		
  //  Get value from list on mouse double click event and perform get product viewer operation
		
		MouseListener mouseListener = new MouseAdapter() {
		    public void mouseClicked(MouseEvent e) {
		        if (e.getClickCount() == 2) {


		           String selectedItem = productList.getSelectedValue().toString();
		           
		           ProductViewer view = controller.getProductDetailsController(selectedItem);
		           
		           if(view!=null){
		           barCodelblO.setText(view.getBarCode());
		           addTextArea.setText(view.getProductDesc());
		           averagePricelblO.setText(view.getAveragePrice());
		           highestPricelblO.setText(view.getHighestPrice());
		           lowestPricelblO.setText(view.getLowestPrice());
		           idealPricelblO.setText(view.getIdealPrice());
		           countPricelblO.setText(view.getNumberPricesCol());
		           }else{

						JOptionPane.showMessageDialog(frame1,
								MessageConstants.message.get(MessageConstants.PRODUCT_NOT_FOUND));
						  
						   barCodelblO.setText("");
				           addTextArea.setText("");
				           averagePricelblO.setText("");
				           highestPricelblO.setText("");
				           lowestPricelblO.setText("");
				           idealPricelblO.setText("");
				           countPricelblO.setText("");
		           }

		         }
		    }
		};
		productList.addMouseListener(mouseListener);
		
//================ USER INTERFACE   ===============//
		
		barCodelbl=new JLabel("BarCode");
		barCodelbl.setOpaque(true);
		barCodelbl.setHorizontalAlignment(SwingConstants.CENTER);
		barCodelbl.setBounds(130,60,60,18);
		barCodelbl.setBackground(new Color(135, 163, 201));
		
		barCodelblO=new JLabel();
		barCodelblO.setOpaque(true);
		barCodelblO.setHorizontalAlignment(SwingConstants.CENTER);
		barCodelblO.setBounds(195,60,95,18);
		barCodelblO.setBackground(new Color(135, 163, 201));
		
					
		productDesclbl=new JLabel("Description");
		productDesclbl.setOpaque(true);
		productDesclbl.setHorizontalAlignment(SwingConstants.CENTER);
		productDesclbl.setBounds(130,85,160,18);
		productDesclbl.setBackground(new Color(135, 163, 201));
		
		/*productDesclblO=new JLabel("Description");
		productDesclblO.setOpaque(true);
		productDesclblO.setHorizontalAlignment(SwingConstants.LEFT);
		productDesclblO.setBounds(130,105,160,80);
		productDesclblO.setBackground(new Color(135, 163, 201));*/
		
		
		averagePricelbl=new JLabel("Avgerage");
		averagePricelbl.setOpaque(true);
		averagePricelbl.setHorizontalAlignment(SwingConstants.CENTER);
		averagePricelbl.setBounds(130,200,60,18);
		averagePricelbl.setBackground(new Color(135, 163, 201));
				
		averagePricelblO=new JLabel();
		averagePricelblO.setOpaque(true);
		averagePricelblO.setHorizontalAlignment(SwingConstants.CENTER);
		averagePricelblO.setBounds(195,200,95,18);
		averagePricelblO.setBackground(new Color(135, 163, 201));
		
		
		lowestPricelbl = new JLabel("Lowest");
		lowestPricelbl.setOpaque(true);
		lowestPricelbl.setBackground(new Color(135, 163, 201));
		lowestPricelbl.setHorizontalAlignment(SwingConstants.CENTER);
		lowestPricelbl.setBounds(130,220,60,18);
				
		lowestPricelblO=new JLabel();
		lowestPricelblO.setOpaque(true);
		lowestPricelblO.setHorizontalAlignment(SwingConstants.CENTER);
		lowestPricelblO.setBounds(195,220,95,18);
		lowestPricelblO.setBackground(new Color(135, 163, 201));
		
		highestPricelbl=new JLabel("Highest");
		highestPricelbl.setOpaque(true);
		highestPricelbl.setHorizontalAlignment(SwingConstants.CENTER);
		highestPricelbl.setBounds(130,240,60,18);
		highestPricelbl.setBackground(new Color(135, 163, 201));
				
		highestPricelblO=new JLabel();
		highestPricelblO.setOpaque(true);
		highestPricelblO.setHorizontalAlignment(SwingConstants.CENTER);
		highestPricelblO.setBounds(195,240,95,18);
		highestPricelblO.setBackground(new Color(135, 163, 201));
		
		idealPricelbl=new JLabel("Ideal");
		idealPricelbl.setOpaque(true);
		idealPricelbl.setHorizontalAlignment(SwingConstants.CENTER);
		idealPricelbl.setBounds(130,260,60,18);
		idealPricelbl.setBackground(new Color(135, 163, 201));
				
		idealPricelblO=new JLabel();
		idealPricelblO.setOpaque(true);
		idealPricelblO.setHorizontalAlignment(SwingConstants.CENTER);
		idealPricelblO.setBounds(195,260,95,18);
		idealPricelblO.setBackground(new Color(135, 163, 201));
					
		countPricelbl=new JLabel("Count");
		countPricelbl.setOpaque(true);
		countPricelbl.setHorizontalAlignment(SwingConstants.CENTER);
		countPricelbl.setBounds(130,280,60,18);
		countPricelbl.setBackground(new Color(135, 163, 201));
				
		countPricelblO=new JLabel();
		countPricelblO.setOpaque(true);
		countPricelblO.setHorizontalAlignment(SwingConstants.CENTER);
		countPricelblO.setBounds(195,280,95,18);
		countPricelblO.setBackground(new Color(135, 163, 201));
		
					
	} // eof constructor
			
	
	
	
	
// Add and remove  component from the panel 
	
	public JPanel addComponentToProductViewerPanel()
	{
		
		addPanel.add(scrollPane);
		//scrollPane.setViewportView(productList);
		addPanel.add(descscrollPane);
		//scrollPane.setViewportView(addTextArea);
		addPanel.add(searchProductTxt);
		addPanel.add(addBtnOk);
	//	addPanel.add(cancelBtnOk);
		addPanel.add(barCodelbl);
		addPanel.add(barCodelblO);
		addPanel.add(productDesclbl);
		addPanel.add(averagePricelbl);
		addPanel.add(averagePricelblO);
		addPanel.add(lowestPricelbl);
		addPanel.add(lowestPricelblO);
		addPanel.add(highestPricelbl);
		addPanel.add(highestPricelblO);
		addPanel.add(idealPricelbl);
		addPanel.add(idealPricelblO);
		addPanel.add(countPricelbl);
		addPanel.add(countPricelblO);
		//addPanel.add(productDesclblO);
		
		
		
		return addPanel;
	}
			
 }  // END OF CLASS 