/*
 * @Author Pramodkumar Varma (41443)
 * @Email :Pramodkumar.varma@zensar.in 
 * 
 * */

package forms;

	

	import java.awt.Cursor;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JScrollPane;

import controller.PrizyPriceControllerImp;

import bean.ProductLoader;

import Util.MessageConstants;
import Util.Utilities;

import dao.ProductLaoderDaoImp;

	public class ProductLoaderPanel extends JFrame{

		private static final long serialVersionUID = 1L;

		private JPanel addPanel;
	   	private JTextField storeNameTxt;
	   	private JTextField productCodeTxt;
	   	private JTextField priceTxt;
		private JScrollPane scrollPane;
	    private JTextArea addTextArea ;   
	    private JButton addBtnOk;	 
	    private JButton cancelBtnOk;
	    private JLabel storeLabel;
	    private JLabel despLabel;
	    private JLabel productCodeLabel;
	    private JLabel priceLabel;
	    private JLabel link ;
	    
	    private PrizyPriceControllerImp controller;
	    	    
	 	    	     
	    ProductLoaderPanel frame1;
	    String viewMember=null;
		
	     		 
		public ProductLoaderPanel() 
		{
			controller = new PrizyPriceControllerImp();
			addPanel = new JPanel();
		    scrollPane = new JScrollPane();
			scrollPane.setBounds(20, 145, 260, 100);
		
			//================================ COMPONENT =======================//				
			    addTextArea = new JTextArea();
			    scrollPane.setViewportView(addTextArea);
			    addTextArea.setWrapStyleWord(true);
			    addTextArea.setLineWrap(true);
			    addTextArea.setBackground(new Color(255,251,174));
			    addTextArea.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
			    addTextArea.setFont(new Font("Dialog", Font.PLAIN, 12));
			    addTextArea.setToolTipText("Additional notes regarding product price");
			    addTextArea.setText("");
			    addTextArea.setEnabled(true);
			    
		    
			storeNameTxt = new JTextField();
			storeNameTxt.setEditable(true);
			storeNameTxt.setBounds(120,30, 162, 20);
			storeNameTxt.setBackground(new Color(255,251,174));
			storeNameTxt.setToolTipText("Enter Store Name");
								
			productCodeTxt = new JTextField();
			productCodeTxt.setEditable(true);
			productCodeTxt.setBounds(120,60, 162, 20);
			productCodeTxt.setBackground(new Color(255,251,174));
			productCodeTxt.setToolTipText("Enter Product code");
			 
						
			priceTxt = new JTextField();
			priceTxt.setEditable(true);
			priceTxt.setBounds(120,90, 162, 20);
			priceTxt.setBackground(new Color(255,251,174));
			priceTxt.setToolTipText("Enter product price");
			 
						    
//=====================  OK BUTTON SAVE RECORD TO DATA BASE=============================//
			    
			addBtnOk = new JButton("SUBMIT");
			addBtnOk.setBounds(40, 280, 100, 25);
			addBtnOk.setToolTipText("Save Entry");
			addBtnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if ((storeNameTxt.getText().trim()).length() < 1 || Utilities.validateInputPattern(storeNameTxt.getText().trim())) {
					JOptionPane.showMessageDialog(frame1,
							MessageConstants.message.get(MessageConstants.INVALID_STORE_NAME));
					storeLabel.setForeground(new Color(192, 29, 53));
				}
				else if ((productCodeTxt.getText().trim()).length() < 1 || Utilities.validateInputPattern(productCodeTxt.getText().trim())) {
					JOptionPane.showMessageDialog(frame1,
							MessageConstants.message.get(MessageConstants.INVALID_PID));
					productCodeLabel.setForeground(new Color(192, 29, 53));
				}
				else if ((priceTxt.getText().trim()).length() < 1|| Utilities.validateInputPrice(priceTxt.getText().trim())) {
					JOptionPane.showMessageDialog(frame1,
							MessageConstants.message.get(MessageConstants.INVALID_PRICE_FORMAT));
					priceLabel.setForeground(new Color(192, 29, 53));
				}
				else if (Utilities.validateInputPattern(addTextArea.getText().trim())) {
					JOptionPane.showMessageDialog(frame1,
							MessageConstants.message.get(MessageConstants.INVALID_NOTES));
					despLabel.setForeground(new Color(192, 29, 53));
				}
				else {
                 
					ProductLoader product = new ProductLoader();
					product.setStore(storeNameTxt.getText().trim());
					product.setProductId(productCodeTxt.getText().trim());
					product.setPrice(Double.parseDouble(priceTxt.getText().trim()));
					product.setNotes(addTextArea.getText().trim());
					product.setEntryDate(Utilities.getDateInStringFormate());
					
					
					
					int flag = controller.addProductLoaderController(product); // 
					ProductLoaderPanel frame1 = null;
					if (flag > 0) {

						JOptionPane.showMessageDialog(frame1,
								MessageConstants.message.get(MessageConstants.ENTRY_SAVED));
						storeNameTxt.setText("");
						productCodeTxt.setText("");
						priceTxt.setText("");
						addTextArea.setText("");
					} else {
						JOptionPane.showMessageDialog(frame1,
								MessageConstants.message.get(MessageConstants.ENTRY_FAILED));
					}

					despLabel.setForeground(Color.BLACK);
					storeLabel.setForeground(Color.BLACK);
					productCodeLabel.setForeground(Color.BLACK);
					priceLabel.setForeground(Color.BLACK);



				} // else end
			}

		}); // end of ActionListener
			
	// =============== RESET BUTTON ================================//
			cancelBtnOk = new JButton("RESET");
			cancelBtnOk.setBounds(160, 280, 100, 25);
			cancelBtnOk.setToolTipText("Reset fields");
			cancelBtnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				storeNameTxt.setText("");
				productCodeTxt.setText("");
				priceTxt.setText("");
				addTextArea.setText("");
							}

		}); // end of ActionListener

			
			
//================ USER INTERFACE   ===============//
			
			storeLabel=new JLabel("Store :");
			storeLabel.setOpaque(true);
			storeLabel.setHorizontalAlignment(SwingConstants.CENTER);
			storeLabel.setBounds(20, 30,80,20);
			storeLabel.setBackground(new Color(135, 163, 201));
						
			productCodeLabel=new JLabel("Product code");
			productCodeLabel.setOpaque(true);
			productCodeLabel.setHorizontalAlignment(SwingConstants.CENTER);
			productCodeLabel.setBounds(20,60,80,20);
			productCodeLabel.setBackground(new Color(135, 163, 201));
			
			
			priceLabel=new JLabel("Price");
			priceLabel.setOpaque(true);
			priceLabel.setHorizontalAlignment(SwingConstants.CENTER);
			priceLabel.setBounds(20,90,80,20);
			priceLabel.setBackground(new Color(135, 163, 201));
						
			despLabel = new JLabel("Notes");
			despLabel.setOpaque(true);
			despLabel.setBackground(new Color(135, 163, 201));
			
			despLabel.setHorizontalAlignment(SwingConstants.CENTER);
			despLabel.setBounds(20, 120,260, 16);
			
						
		} // eof constructor
				
		
		
		
		
	// Add and remove  component from the panel 
		
		public JPanel addComponentToProductLoaderPanel()
		{
			
			addPanel.add(scrollPane);
			scrollPane.setViewportView(addTextArea);
			addPanel.add(storeNameTxt);
			addPanel.add(priceTxt);
			addPanel.add(productCodeTxt);
			addPanel.add(addBtnOk);
			addPanel.add(cancelBtnOk);
			addPanel.add(storeLabel);
			addPanel.add(productCodeLabel);
			addPanel.add(priceLabel);
			addPanel.add(despLabel);
			
			
			return addPanel;
		}
				
				
 }  // END OF CLASS 