/*
 * @Author Pramodkumar Varma (41443)
 * @Email :Pramodkumar.varma@zensar.in 
 * 
 * */

package forms;

import javax.swing.UIManager;
import forms.MasterForm;



public class Main {
	
		  
	public static void main(String arg[])
	{
		
		try
		
	    {
	       
	        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
	        MasterForm mainForm=new MasterForm();
	        mainForm.setVisible(true);
			
	      //  SwingUtilities.updateComponentTreeUI(frame);
			 
			
	    }
	    catch(Exception ex)
	    {
	        ex.printStackTrace();
	    }

			
			
		
	}
	
	

}
