/*
 * @Author Pramodkumar Varma (41443)
 * @Email :Pramodkumar.varma@zensar.in 
 * 
 * */

package forms;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

import dao.DBConnection;

public class MasterForm  extends JFrame {

	
	private JPanel contentPane;
	private JPanel addPVPanel,addPLPanel;
    private	JTabbedPane tabbedPane;
    private static final long serialVersionUID = 1L;
    private JMenuBar menuBar;
    
    ProductViewerPanel productViewerPanel;
    ProductLoaderPanel  plPanel;

	public MasterForm() {
		
		productViewerPanel=new ProductViewerPanel();
		plPanel =new ProductLoaderPanel();
		
		setResizable(false);
		
		setTitle("The Prizy Pricer");
		setPreferredSize(new Dimension(320,420));
		setMaximumSize(new Dimension(320,420)) ;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300,250,320,420);    //---------------------- Set Location
		
		//setIconImage(Toolkit.getDefaultToolkit().getImage("images\\logo.png"));
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(new Color(95,117,147));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 600, 21);
		contentPane.add(menuBar);
						
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(5,20,300,370); 

		contentPane.add(tabbedPane);
			
		
//===========================  ADD  PANEL   =============//
				
		addPLPanel=plPanel.addComponentToProductLoaderPanel();
		tabbedPane.addTab("Product Loader", null, addPLPanel, null);
		addPLPanel.setLayout(null);
		addPLPanel.setBackground(new Color(95,117,147));
		
		addPVPanel = productViewerPanel.addComponentToProductViewerPanel();
		tabbedPane.addTab("Product Viewer", null, addPVPanel, null);
		addPVPanel.setLayout(null);
		addPVPanel.setBackground(new Color(95,117,147));
				
//==================== DISPLAY TIMER ON JFRAME====================//
		
		final	JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBackground(Color.BLUE);
		
			lblNewLabel_1.setBounds(120, 22,200, 21);
			lblNewLabel_1.setForeground(new Color(255, 255, 255));
			contentPane.add(lblNewLabel_1);
			
			final DateFormat timeFormat = new SimpleDateFormat("E dd/MM/yyyy ' || ' HH:mm:ss a"); 
			ActionListener timerListener = new ActionListener()  
	        {  
	            public void actionPerformed(ActionEvent e)  
	            {  
	               Date date = new Date();
	                String time = timeFormat.format(date);  
	                lblNewLabel_1.setText(time);  
	            } };  
	        
	            Timer timer = new Timer(1000, timerListener);  
	            timer.setInitialDelay(0);  
	            timer.start();	
	       
	            final JLabel dbConnect =new JLabel("");
	   	     dbConnect.setBounds(0,21,555,2);
	   	     dbConnect.setOpaque(false);
	   	     contentPane.add(dbConnect);
	   	    
	   	     DBConnection db= new DBConnection();
	   	     
	   	     try
	   	     {
	   	     Connection con = db.getConnection();
	   	     
	   	     if (con!=null)
	   	     {
	   	    	  dbConnect.setOpaque(true);
	   	    	// dbConnect.setBackground(new Color(40,210,91)); // green
	   	    	  
	   	    	 dbConnect.setBackground(new Color(3,248,174));
	   	    	// dbConnect.setText("Connected");
	   	    	// dbConnect.setHorizontalAlignment(SwingConstants.CENTER);
	   	     }
	   	     else{ 
	   	    	  dbConnect.setOpaque(true);
	   	    		 dbConnect.setBackground(new Color(250,31,1));
	   	    		
	   	    	//	 dbConnect.setText("DB Error");
	   	    	//	 dbConnect.setHorizontalAlignment(SwingConstants.CENTER);
	               	 
	       	
	   	    		 }
	   	     }catch(Exception ex){ex.printStackTrace();}
		
	} // constructor end
		
}
