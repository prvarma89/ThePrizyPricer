# ACH

<aside class="notice">Basics of ACH</aside>

Learn How ACH Payments Work:


ACH payments are electronic payments made through the Automated Clearing House (ACH) Network. 
Funds move from one bank account to another with the help of an intermediary that routes funds to the final destination. 
Computerized payments can provide benefits to both merchants and consumers. 
Payments are inexpensive, they can be automated, and record-keeping is easier with electronic payments.


ACH payments are simply electronic transfers from one bank account to another. Common uses include:

A customer pays a service provider.
An employer deposits money to an employee's checking account.
A consumer moves funds from one bank to another.
A business pays a supplier for products.
A taxpayer sends funds to the IRS or local organizations online.
To complete payments, the organization requesting a payment (whether they want to send funds or receive funds) needs to get bank account information from the other party involved. For example, employers require employees using direct deposit to provide the following details:

The name of the bank or credit union receiving funds
The type of account at that bank (checking or savings)
The bank’s ABA routing number
The recipient’s account number
With that information, a payment can be created and routed to the correct account. The same details are required to make pre-authorized withdrawals from customer accounts.

ACH payments are typically electronic from start to finish. But sometimes paper checks get converted to electronic payments, and the funds move through the ACH system.

