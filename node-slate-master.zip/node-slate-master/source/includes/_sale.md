# Card

## SALE



```ruby
require 'Sale'

api = Kittn::APIClient.authorize!('meowmeowmeow')
api.Sale.get
```

```python
import Sale

api = Sale.authorize('meowmeowmeow')
api.Sale.get()
```

```bash
curl "http://example.com/api/Sale"
  -H "Authorization: meowmeowmeow"
```

```javascript
const Sale = require('Sale');

let api = Sale.authorize('meowmeowmeow');
let Sale = api.Sale.get();
```

> The above command returns JSON structured like this:

```json
[
  {
    "id": 1,
    "name": "Fluffums",
    "breed": "calico",
    "fluffiness": 6,
    "cuteness": 7
  },
  {
    "id": 2,
    "name": "Max",
    "breed": "unknown",
    "fluffiness": 5,
    "cuteness": 10
  }
]
```

This endpoint retrieves all Sale.

### HTTP Request

`GET http://example.com/api/Sale`

### Query Parameters

Parameter | Default | Description
--------- | ------- | -----------
include_cats | false | If set to true, the result will also include cats.
available | true | If set to false, the result will include Sale that have already been adopted.

<aside class="success">
Remember — a happy kitten is an authenticated kitten!
</aside>

## VOID

```ruby
require 'kittn'

api = Kittn::APIClient.authorize!('meowmeowmeow')
api.Sale.get(2)
```

```python
import kittn

api = kittn.authorize('meowmeowmeow')
api.Sale.get(2)
```

```bash
curl "http://example.com/api/Sale/2"
  -H "Authorization: meowmeowmeow"
```

```javascript
const kittn = require('kittn');

let api = kittn.authorize('meowmeowmeow');
let max = api.Sale.get(2);
```

> The above command returns JSON structured like this:

```json
{
  "id": 2,
  "name": "Max",
  "breed": "unknown",
  "fluffiness": 5,
  "cuteness": 10
}
```

This endpoint retrieves a specific kitten.

<aside class="warning">Inside HTML code blocks like this one, you can't use Markdown, so use <code>&lt;code&gt;</code> blocks to denote code.</aside>

### HTTP Request

`GET http://example.com/Sale/<ID>`

### URL Parameters

Parameter | Description
--------- | -----------
ID | The ID of the kitten to retrieve  

## RETURN

```ruby
require 'kittn'

api = Kittn::APIClient.authorize!('meowmeowmeow')
api.Sale.get(2)
```

```python
import kittn

api = kittn.authorize('meowmeowmeow')
api.Sale.get(2)
```

```bash
curl "http://example.com/api/Sale/2"
  -H "Authorization: meowmeowmeow"
```

```javascript
const kittn = require('kittn');

let api = kittn.authorize('meowmeowmeow');
let max = api.Sale.get(2);
```

> The above command returns JSON structured like this:

```json
{
  "id": 2,
  "name": "Max",
  "breed": "unknown",
  "fluffiness": 5,
  "cuteness": 10
}
```

This endpoint retrieves a specific kitten.

<aside class="warning">Inside HTML code blocks like this one, you can't use Markdown, so use <code>&lt;code&gt;</code> blocks to denote code.</aside>

### HTTP Request

`GET http://example.com/Sale/<ID>`

### URL Parameters

Parameter | Description
--------- | -----------
ID | The ID of the kitten to retrieve  


## SETTEL

```ruby
require 'kittn'

api = Kittn::APIClient.authorize!('meowmeowmeow')
api.Sale.get(2)
```

```python
import kittn

api = kittn.authorize('meowmeowmeow')
api.Sale.get(2)
```

```bash
curl "http://example.com/api/Sale/2"
  -H "Authorization: meowmeowmeow"
```

```javascript
const kittn = require('kittn');

let api = kittn.authorize('meowmeowmeow');
let max = api.Sale.get(2);
```

> The above command returns JSON structured like this:

```json
{
  "id": 2,
  "name": "Max",
  "breed": "unknown",
  "fluffiness": 5,
  "cuteness": 10
}
```

This endpoint retrieves a specific kitten.

<aside class="warning">Inside HTML code blocks like this one, you can't use Markdown, so use <code>&lt;code&gt;</code> blocks to denote code.</aside>

### HTTP Request

`GET http://example.com/Sale/<ID>`

### URL Parameters

Parameter | Description
--------- | -----------
ID | The ID of the kitten to retrieve  